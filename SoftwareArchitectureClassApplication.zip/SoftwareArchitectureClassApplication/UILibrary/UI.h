#pragma once

#include "UILIbraryExports.h"
#include "..\Core\LinkedList.h"



class UILIBRARY_API UI
{
public:

	UI();

	void Init();

	void StartGUILoop();

};