#pragma once
#include "AutomationBindingExports.h"
namespace AutomationAPI
{
	class AUTOMATIONBINDING_API ICADObject
	{

		virtual int GetGuid() = 0;


	};
}