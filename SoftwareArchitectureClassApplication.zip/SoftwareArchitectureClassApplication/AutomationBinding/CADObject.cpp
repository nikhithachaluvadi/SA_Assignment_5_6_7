#include "CADObject.h"

int AutomationAPI::CADObject::GetGuid()
{
	return 0;
}
