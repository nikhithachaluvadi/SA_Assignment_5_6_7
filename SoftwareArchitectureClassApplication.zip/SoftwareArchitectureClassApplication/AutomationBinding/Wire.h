#pragma once
#include "AutomationBindingExports.h"
#include "CADObject.h"

namespace AutomationAPI
{
	class Wire : CADObject
	{
		public:


		private:

	};
}

