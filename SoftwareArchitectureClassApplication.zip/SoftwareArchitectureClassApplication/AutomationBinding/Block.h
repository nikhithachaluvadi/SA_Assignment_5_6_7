#pragma once
#include "AutomationBindingExports.h"
#include "CADObject.h"

namespace AutomationAPI
{
	class Block : CADObject
	{
		public:


		private:

	};
}

