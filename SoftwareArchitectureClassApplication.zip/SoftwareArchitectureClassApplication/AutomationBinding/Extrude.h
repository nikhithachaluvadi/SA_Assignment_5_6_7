#pragma once
#include "AutomationBindingExports.h"
#include "CADObject.h"

namespace AutomationAPI
{
	class AUTOMATIONBINDING_API Extrude : CADObject
	{


	};
}
