#pragma once

#include <string>


void ReadInPartFile(int& guid, std::string partFilePath);

