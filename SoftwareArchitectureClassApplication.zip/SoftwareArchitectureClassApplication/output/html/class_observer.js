var class_observer =
[
    [ "Observer", "class_observer.html#ad6e4ca5a41a33cd105a7981804ef7cb8", null ],
    [ "~Observer", "class_observer.html#afcc6b67be6c386f2f3d2c363aa59cb47", null ],
    [ "PrintInfo", "class_observer.html#a44a29bbcae10786889bdbb1b893ce5a4", null ],
    [ "RemoveMeFromTheList", "class_observer.html#add6dc712ca2df410b40dde7be83c1084", null ],
    [ "Update", "class_observer.html#ae21fdb3c8e3cc393f34e5ea6ed083790", null ],
    [ "UpdateOnEventType", "class_observer.html#ae35cfaa2cd8569cdaf9baf6286148c00", null ]
];