var namespaces_dup =
[
    [ "CoreLibrary1", "namespace_core_library1.html", "namespace_core_library1" ]
];