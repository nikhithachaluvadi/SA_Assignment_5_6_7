var class_session =
[
    [ "Session", "class_session.html#a7f1698b79c05919ce69ad84dbc733067", null ],
    [ "~Session", "class_session.html#ac44f83f3472d320993e4d28d16846cc8", null ],
    [ "Attach", "class_session.html#a09568d0f0f12fcaa2f753fb75309ee6f", null ],
    [ "CreateMessage", "class_session.html#aa87480026dd611b5b4e990b016580b6b", null ],
    [ "CreateMessage", "class_session.html#a3dd2af4a20e71f2e1d33ad5bf2c42421", null ],
    [ "Detach", "class_session.html#a4cb83c4e92c6b745e6045e3fcc5cee1e", null ],
    [ "Notify", "class_session.html#a5f92ef5e6acccd3be19acaf4d301d674", null ],
    [ "Notify", "class_session.html#a24d02e47e7727a1e57c2f5680c1142e8", null ],
    [ "operator=", "class_session.html#ac566ee36d98c1a88a2a06a3d5162d275", null ]
];