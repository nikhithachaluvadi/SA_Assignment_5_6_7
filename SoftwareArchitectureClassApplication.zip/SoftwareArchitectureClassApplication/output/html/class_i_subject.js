var class_i_subject =
[
    [ "~ISubject", "class_i_subject.html#a6c5b23ca0dc6b162f13b565319f78bd8", null ],
    [ "Attach", "class_i_subject.html#adb7192a450141dce4d631dceb4751f23", null ],
    [ "Detach", "class_i_subject.html#a190f4d8a851edfd6a1b28b806800f11d", null ],
    [ "Notify", "class_i_subject.html#a719fcebc1bb7d0a7e83c52a58c24a75d", null ],
    [ "Notify", "class_i_subject.html#a71cec40009716d480420ac899e82df25", null ]
];