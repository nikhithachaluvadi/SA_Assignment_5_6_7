var annotated_dup =
[
    [ "CoreLibrary1", "namespace_core_library1.html", [
      [ "IBuilder", "class_core_library1_1_1_i_builder.html", null ],
      [ "ITaskObject", "class_core_library1_1_1_i_task_object.html", null ],
      [ "Task", "class_core_library1_1_1_task.html", null ],
      [ "TaskBuilder", "class_core_library1_1_1_task_builder.html", "class_core_library1_1_1_task_builder" ],
      [ "TaskFeatureCollection", "class_core_library1_1_1_task_feature_collection.html", "class_core_library1_1_1_task_feature_collection" ],
      [ "TaskObject", "class_core_library1_1_1_task_object.html", "class_core_library1_1_1_task_object" ]
    ] ],
    [ "CCore1", "class_c_core1.html", "class_c_core1" ],
    [ "helper1", "classhelper1.html", null ],
    [ "ISubject", "class_i_subject.html", "class_i_subject" ],
    [ "ITaskObserver", "class_i_task_observer.html", "class_i_task_observer" ],
    [ "Observer", "class_observer.html", "class_observer" ],
    [ "Session", "class_session.html", "class_session" ]
];