var class_core_a_p_i_1_1_session =
[
    [ "~Session", "class_core_a_p_i_1_1_session.html#afa82aed8c0a263b3f103f3d1e37dfce3", null ],
    [ "MakePart", "class_core_a_p_i_1_1_session.html#ac873f28575b9c0bbe831d101947a7b7d", null ],
    [ "OpenPart", "class_core_a_p_i_1_1_session.html#a6b1223cf6325cb826ad63009441e9aa5", null ]
];