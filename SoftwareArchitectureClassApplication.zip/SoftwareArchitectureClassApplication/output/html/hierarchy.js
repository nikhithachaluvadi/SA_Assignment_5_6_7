var hierarchy =
[
    [ "CCore1", "class_c_core1.html", null ],
    [ "helper1", "classhelper1.html", null ],
    [ "CoreLibrary1::IBuilder", "class_core_library1_1_1_i_builder.html", [
      [ "CoreLibrary1::TaskBuilder", "class_core_library1_1_1_task_builder.html", null ]
    ] ],
    [ "ISubject", "class_i_subject.html", [
      [ "Session", "class_session.html", null ]
    ] ],
    [ "CoreLibrary1::ITaskObject", "class_core_library1_1_1_i_task_object.html", [
      [ "CoreLibrary1::TaskObject", "class_core_library1_1_1_task_object.html", [
        [ "CoreLibrary1::Task", "class_core_library1_1_1_task.html", null ]
      ] ]
    ] ],
    [ "ITaskObserver", "class_i_task_observer.html", [
      [ "Observer", "class_observer.html", null ]
    ] ],
    [ "CoreLibrary1::TaskFeatureCollection", "class_core_library1_1_1_task_feature_collection.html", null ]
];