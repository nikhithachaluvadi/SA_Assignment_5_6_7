var searchData=
[
  ['setid_73',['SetId',['../class_core_library1_1_1_task_builder.html#a47def3b4815156194d4c4a29faeca9a3',1,'CoreLibrary1::TaskBuilder']]],
  ['settaskwithstring_74',['SetTaskWithString',['../class_core_library1_1_1_task_builder.html#a600b501ff948d10f2482c771950e42e2',1,'CoreLibrary1::TaskBuilder']]],
  ['settaskwithstringandid_75',['SetTaskWithStringandID',['../class_core_library1_1_1_task_builder.html#a6e03615f44a4f821526956c41cad1d06',1,'CoreLibrary1::TaskBuilder']]],
  ['settype_76',['SetType',['../class_core_library1_1_1_task_builder.html#a2a883aec3d36a5218a3de1050111d5a2',1,'CoreLibrary1::TaskBuilder']]]
];
