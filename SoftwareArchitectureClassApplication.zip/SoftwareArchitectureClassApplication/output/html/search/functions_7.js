var searchData=
[
  ['removemefromthelist_72',['RemoveMeFromTheList',['../class_observer.html#add6dc712ca2df410b40dde7be83c1084',1,'Observer']]]
];
