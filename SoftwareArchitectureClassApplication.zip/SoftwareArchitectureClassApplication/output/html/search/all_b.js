var searchData=
[
  ['savetask_24',['SaveTask',['../class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110a9d2bb3735ba4355a5b2ebbd66969f596',1,'ITaskObserver']]],
  ['session_25',['Session',['../class_session.html',1,'']]],
  ['setid_26',['SetId',['../class_core_library1_1_1_task_builder.html#a47def3b4815156194d4c4a29faeca9a3',1,'CoreLibrary1::TaskBuilder']]],
  ['settaskwithstring_27',['SetTaskWithString',['../class_core_library1_1_1_task_builder.html#a600b501ff948d10f2482c771950e42e2',1,'CoreLibrary1::TaskBuilder']]],
  ['settaskwithstringandid_28',['SetTaskWithStringandID',['../class_core_library1_1_1_task_builder.html#a6e03615f44a4f821526956c41cad1d06',1,'CoreLibrary1::TaskBuilder']]],
  ['settype_29',['SetType',['../class_core_library1_1_1_task_builder.html#a2a883aec3d36a5218a3de1050111d5a2',1,'CoreLibrary1::TaskBuilder']]]
];
