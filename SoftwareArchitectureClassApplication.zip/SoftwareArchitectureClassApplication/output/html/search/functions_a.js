var searchData=
[
  ['update_79',['Update',['../class_i_task_observer.html#a453ffd7d491d7c36b8bf5fbaeeb2f786',1,'ITaskObserver::Update()'],['../class_observer.html#ae21fdb3c8e3cc393f34e5ea6ed083790',1,'Observer::Update(const std::string &amp;message_from_subject) override']]],
  ['updateoneventtype_80',['UpdateOnEventType',['../class_observer.html#ae35cfaa2cd8569cdaf9baf6286148c00',1,'Observer']]]
];
