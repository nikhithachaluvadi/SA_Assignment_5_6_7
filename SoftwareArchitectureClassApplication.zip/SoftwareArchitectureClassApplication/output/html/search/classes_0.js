var searchData=
[
  ['ccore1_45',['CCore1',['../class_c_core1.html',1,'']]]
];
