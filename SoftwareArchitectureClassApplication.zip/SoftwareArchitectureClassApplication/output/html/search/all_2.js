var searchData=
[
  ['detach_7',['Detach',['../class_session.html#a4cb83c4e92c6b745e6045e3fcc5cee1e',1,'Session::Detach()'],['../class_i_subject.html#a190f4d8a851edfd6a1b28b806800f11d',1,'ISubject::Detach()']]]
];
