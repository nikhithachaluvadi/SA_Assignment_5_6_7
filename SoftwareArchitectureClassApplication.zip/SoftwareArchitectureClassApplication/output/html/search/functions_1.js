var searchData=
[
  ['checkifexists_59',['CheckIfExists',['../classhelper1.html#af28a64e75bf406feb2f520ce71f81561',1,'helper1']]],
  ['commit_60',['Commit',['../class_core_library1_1_1_task_builder.html#a93baf557b57fb3d0049ad711aa77cf5c',1,'CoreLibrary1::TaskBuilder']]],
  ['createmessage_61',['CreateMessage',['../class_session.html#aa87480026dd611b5b4e990b016580b6b',1,'Session::CreateMessage(ITaskObserver::EventTypes eventType)'],['../class_session.html#a3dd2af4a20e71f2e1d33ad5bf2c42421',1,'Session::CreateMessage(std::string message=&quot;Empty&quot;)']]],
  ['createtaskbuilder_62',['CreateTaskBuilder',['../class_core_library1_1_1_task_feature_collection.html#ab8af0052f59ecbc2ada2c7e22b3d3d55',1,'CoreLibrary1::TaskFeatureCollection']]]
];
