var searchData=
[
  ['savetask_88',['SaveTask',['../class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110a9d2bb3735ba4355a5b2ebbd66969f596',1,'ITaskObserver']]]
];
