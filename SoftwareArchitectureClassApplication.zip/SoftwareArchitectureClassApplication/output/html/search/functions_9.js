var searchData=
[
  ['taskfeaturecollection_77',['TaskFeatureCollection',['../class_core_library1_1_1_task_feature_collection.html#ad148357725fa35c4f9d4a3b317c7280d',1,'CoreLibrary1::TaskFeatureCollection']]],
  ['todotask_78',['TODOTask',['../classhelper1.html#a7e19b6193ba90b067a2fc2a53a6e0773',1,'helper1']]]
];
