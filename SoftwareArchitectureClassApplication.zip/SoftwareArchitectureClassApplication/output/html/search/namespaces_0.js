var searchData=
[
  ['corelibrary1_57',['CoreLibrary1',['../namespace_core_library1.html',1,'']]]
];
