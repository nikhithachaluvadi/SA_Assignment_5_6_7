var searchData=
[
  ['attach_0',['Attach',['../class_session.html#a09568d0f0f12fcaa2f753fb75309ee6f',1,'Session::Attach()'],['../class_i_subject.html#adb7192a450141dce4d631dceb4751f23',1,'ISubject::Attach()']]]
];
