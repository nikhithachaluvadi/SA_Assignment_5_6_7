var searchData=
[
  ['observer_70',['Observer',['../class_observer.html#ad6e4ca5a41a33cd105a7981804ef7cb8',1,'Observer']]]
];
