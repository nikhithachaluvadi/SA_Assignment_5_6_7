var searchData=
[
  ['_7eisubject_81',['~ISubject',['../class_i_subject.html#a6c5b23ca0dc6b162f13b565319f78bd8',1,'ISubject']]],
  ['_7eitaskobserver_82',['~ITaskObserver',['../class_i_task_observer.html#aca6d919cdc6d315fc45cdcda98bdeafe',1,'ITaskObserver']]],
  ['_7eobserver_83',['~Observer',['../class_observer.html#afcc6b67be6c386f2f3d2c363aa59cb47',1,'Observer']]],
  ['_7etaskfeaturecollection_84',['~TaskFeatureCollection',['../class_core_library1_1_1_task_feature_collection.html#ab6eb552864660374d0ec902c5533c9ce',1,'CoreLibrary1::TaskFeatureCollection']]]
];
