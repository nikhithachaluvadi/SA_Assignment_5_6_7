var searchData=
[
  ['updatetask_91',['UpdateTask',['../class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110aaf8b2ea83a02304785ab763ad5e95e0d',1,'ITaskObserver']]]
];
