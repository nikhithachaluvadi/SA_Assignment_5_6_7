var searchData=
[
  ['taskidandstringcombination_89',['TaskIdAndStringCombination',['../class_core_library1_1_1_task_builder.html#a3be20b01843f7ab48f8b46008a3c46e4ae80f903d338013460641b38352c4c235',1,'CoreLibrary1::TaskBuilder']]],
  ['taskstring_90',['TaskString',['../class_core_library1_1_1_task_builder.html#a3be20b01843f7ab48f8b46008a3c46e4ac658a11ed66b5bfb1b268ae27bda17dc',1,'CoreLibrary1::TaskBuilder']]]
];
