var searchData=
[
  ['observer_51',['Observer',['../class_observer.html',1,'']]]
];
