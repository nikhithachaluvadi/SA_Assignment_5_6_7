var searchData=
[
  ['removemefromthelist_22',['RemoveMeFromTheList',['../class_observer.html#add6dc712ca2df410b40dde7be83c1084',1,'Observer']]],
  ['removetask_23',['RemoveTask',['../class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110aa25256fd87b68626ab70dcc3aca4afae',1,'ITaskObserver']]]
];
