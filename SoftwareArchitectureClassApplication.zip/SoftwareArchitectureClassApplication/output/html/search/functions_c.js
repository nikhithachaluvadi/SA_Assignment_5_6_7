var searchData=
[
  ['_7eisubject_69',['~ISubject',['../class_i_subject.html#a6c5b23ca0dc6b162f13b565319f78bd8',1,'ISubject']]],
  ['_7eitaskobserver_70',['~ITaskObserver',['../class_i_task_observer.html#aca6d919cdc6d315fc45cdcda98bdeafe',1,'ITaskObserver']]]
];
