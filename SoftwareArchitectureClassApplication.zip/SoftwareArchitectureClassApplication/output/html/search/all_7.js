var searchData=
[
  ['notify_19',['Notify',['../class_session.html#a5f92ef5e6acccd3be19acaf4d301d674',1,'Session::Notify() override'],['../class_session.html#a24d02e47e7727a1e57c2f5680c1142e8',1,'Session::Notify(ITaskObserver::EventTypes eventType) override'],['../class_i_subject.html#a719fcebc1bb7d0a7e83c52a58c24a75d',1,'ISubject::Notify()=0'],['../class_i_subject.html#a71cec40009716d480420ac899e82df25',1,'ISubject::Notify(ITaskObserver::EventTypes eventType)=0']]]
];
