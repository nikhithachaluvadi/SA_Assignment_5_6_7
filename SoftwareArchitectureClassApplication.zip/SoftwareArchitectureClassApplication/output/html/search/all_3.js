var searchData=
[
  ['eventtypes_8',['EventTypes',['../class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110',1,'ITaskObserver']]]
];
