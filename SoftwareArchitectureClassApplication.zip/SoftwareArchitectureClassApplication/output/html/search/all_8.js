var searchData=
[
  ['observer_20',['Observer',['../class_observer.html',1,'Observer'],['../class_observer.html#ad6e4ca5a41a33cd105a7981804ef7cb8',1,'Observer::Observer()']]]
];
