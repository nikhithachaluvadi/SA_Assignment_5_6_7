var searchData=
[
  ['removetask_87',['RemoveTask',['../class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110aa25256fd87b68626ab70dcc3aca4afae',1,'ITaskObserver']]]
];
