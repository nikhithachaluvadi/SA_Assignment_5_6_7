var class_i_task_observer =
[
    [ "EventTypes", "class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110", [
      [ "SaveTask", "class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110a9d2bb3735ba4355a5b2ebbd66969f596", null ],
      [ "RemoveTask", "class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110aa25256fd87b68626ab70dcc3aca4afae", null ],
      [ "UpdateTask", "class_i_task_observer.html#a3dff6c48184276d1f208d8305ac66110aaf8b2ea83a02304785ab763ad5e95e0d", null ]
    ] ],
    [ "~ITaskObserver", "class_i_task_observer.html#aca6d919cdc6d315fc45cdcda98bdeafe", null ],
    [ "Update", "class_i_task_observer.html#a453ffd7d491d7c36b8bf5fbaeeb2f786", null ]
];