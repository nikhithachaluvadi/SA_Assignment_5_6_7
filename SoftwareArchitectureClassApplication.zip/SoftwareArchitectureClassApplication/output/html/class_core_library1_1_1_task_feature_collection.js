var class_core_library1_1_1_task_feature_collection =
[
    [ "TaskFeatureCollection", "class_core_library1_1_1_task_feature_collection.html#ad148357725fa35c4f9d4a3b317c7280d", null ],
    [ "~TaskFeatureCollection", "class_core_library1_1_1_task_feature_collection.html#ab6eb552864660374d0ec902c5533c9ce", null ],
    [ "CreateTaskBuilder", "class_core_library1_1_1_task_feature_collection.html#ab8af0052f59ecbc2ada2c7e22b3d3d55", null ]
];