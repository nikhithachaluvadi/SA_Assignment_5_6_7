var class_core_library1_1_1_task_builder =
[
    [ "TaskBuilderTypes", "class_core_library1_1_1_task_builder.html#a3be20b01843f7ab48f8b46008a3c46e4", [
      [ "TaskString", "class_core_library1_1_1_task_builder.html#a3be20b01843f7ab48f8b46008a3c46e4ac658a11ed66b5bfb1b268ae27bda17dc", null ],
      [ "TaskIdAndStringCombination", "class_core_library1_1_1_task_builder.html#a3be20b01843f7ab48f8b46008a3c46e4ae80f903d338013460641b38352c4c235", null ]
    ] ],
    [ "Commit", "class_core_library1_1_1_task_builder.html#a93baf557b57fb3d0049ad711aa77cf5c", null ],
    [ "GetTask", "class_core_library1_1_1_task_builder.html#a939c9a5fd80dff128172975d60fbce2b", null ],
    [ "GetTaskName", "class_core_library1_1_1_task_builder.html#aa790cea772b9228045f27fe26ed97426", null ],
    [ "GetType", "class_core_library1_1_1_task_builder.html#a85fef18d4b935167749609d610f32b6e", null ],
    [ "SetId", "class_core_library1_1_1_task_builder.html#a47def3b4815156194d4c4a29faeca9a3", null ],
    [ "SetTaskWithString", "class_core_library1_1_1_task_builder.html#a600b501ff948d10f2482c771950e42e2", null ],
    [ "SetTaskWithStringandID", "class_core_library1_1_1_task_builder.html#a6e03615f44a4f821526956c41cad1d06", null ],
    [ "SetType", "class_core_library1_1_1_task_builder.html#a2a883aec3d36a5218a3de1050111d5a2", null ]
];