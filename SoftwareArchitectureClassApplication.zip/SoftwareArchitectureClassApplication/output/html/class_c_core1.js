var class_c_core1 =
[
    [ "CCore1", "class_c_core1.html#abbd9e1274652eb2886e10740a1b0742a", null ]
];