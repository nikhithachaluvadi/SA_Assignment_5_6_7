var class_core_a_p_i_1_1_part =
[
    [ "~Part", "class_core_a_p_i_1_1_part.html#a36e261aa9c5cfaf06499b46e7ebfcbac", null ],
    [ "Features", "class_core_a_p_i_1_1_part.html#a2d4e3eefb2e35e7a4f99af71a333f339", null ],
    [ "MakeWidgetFeature", "class_core_a_p_i_1_1_part.html#a7eeb7b5eb6a2adeac62985bb0ef0ec96", null ],
    [ "Save", "class_core_a_p_i_1_1_part.html#a476e0093ccbb5a1e8039706936b6f57d", null ]
];