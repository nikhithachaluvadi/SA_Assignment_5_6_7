var namespace_core_library1 =
[
    [ "IBuilder", "class_core_library1_1_1_i_builder.html", null ],
    [ "ITaskObject", "class_core_library1_1_1_i_task_object.html", null ],
    [ "Task", "class_core_library1_1_1_task.html", null ],
    [ "TaskBuilder", "class_core_library1_1_1_task_builder.html", "class_core_library1_1_1_task_builder" ],
    [ "TaskFeatureCollection", "class_core_library1_1_1_task_feature_collection.html", "class_core_library1_1_1_task_feature_collection" ],
    [ "TaskObject", "class_core_library1_1_1_task_object.html", "class_core_library1_1_1_task_object" ]
];