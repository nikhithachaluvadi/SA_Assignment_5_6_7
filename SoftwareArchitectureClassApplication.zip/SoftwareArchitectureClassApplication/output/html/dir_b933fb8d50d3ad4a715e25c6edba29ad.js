var dir_b933fb8d50d3ad4a715e25c6edba29ad =
[
    [ "Core1.h", "_core1_8h_source.html", null ],
    [ "CoreSession.h", "_core_session_8h_source.html", null ],
    [ "framework.h", "framework_8h_source.html", null ],
    [ "IBuilder.h", "_i_builder_8h_source.html", null ],
    [ "ISubject.h", "_i_subject_8h_source.html", null ],
    [ "ITaskObject.h", "_i_task_object_8h_source.html", null ],
    [ "ITaskObserver.h", "_i_task_observer_8h_source.html", null ],
    [ "Task.h", "_task_8h_source.html", null ],
    [ "TaskBuilder.h", "_task_builder_8h_source.html", null ],
    [ "TaskFeatureCollection.h", "_task_feature_collection_8h_source.html", null ],
    [ "TaskObject.h", "_task_object_8h_source.html", null ],
    [ "TaskObserver.h", "_task_observer_8h_source.html", null ]
];