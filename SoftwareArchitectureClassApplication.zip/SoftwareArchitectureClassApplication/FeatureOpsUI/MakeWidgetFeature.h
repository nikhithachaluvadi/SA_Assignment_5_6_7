#pragma once

#include "FeatureOpsUIExports.h"

class PartFile;

FEATUREOPSUI_API void AddWidgetFeatureToPartUI(PartFile* partFile, bool option1, int values);


