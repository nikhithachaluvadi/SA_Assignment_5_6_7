# SoftwareArchitectureCLassApplication
This is sandbox code to show proof of concept usages of some principles taught in University of Cincinnati's Software Architecture Class.

This code base will be used for several assignments, but it's value comes from having several libraries in play, as well as some example usages of concepts of singletons, static initializers, journaling, and automation APIs

Additionally, this also shows how to setup a Basic Action to verify a merge request compiles or not.
