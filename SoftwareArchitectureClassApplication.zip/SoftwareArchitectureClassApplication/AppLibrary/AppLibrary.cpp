// AppLibrary.cpp : Defines the exported functions for the DLL.
//

#include "framework.h"
#include "AppLibrary.h"


//// This is an example of an exported variable
//APPLIBRARY_API int nAppLibrary=0;
//
//// This is an example of an exported function.
//APPLIBRARY_API int fnAppLibrary(void)
//{
//    return 0;
//}
//
//// This is the constructor of a class that has been exported.
//CAppLibrary::CAppLibrary()
//{
//    return;
//}



