#pragma once
#include <iostream>
#include <map>
#include <string>

typedef void* (*dataReaderFunction)(std::ifstream& streamObject);