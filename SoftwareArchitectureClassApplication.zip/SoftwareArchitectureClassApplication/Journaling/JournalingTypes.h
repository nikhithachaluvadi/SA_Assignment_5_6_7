#pragma once

enum class CannedGlobals
{
	NOT_CANNED,
	SESSION
	
};

enum class JournalingLanguage
{
	CPP,
	Java
};
